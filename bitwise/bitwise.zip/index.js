/**
 * @param {number} m
 * @param {number} n
 * @return {number}
 */

var rangeBitwiseAnd = function(m, n) {
  let result = m;
  for (let i = m; i <= n; i++) {
    result &= i;
  }

  return result;
};

console.log(rangeBitwiseAnd(0, 2147483647));

module.exports = {
  rangeBitwiseAnd
};
