const { rangeBitwiseAnd } = require("./");

describe("rangeBitwiseAnd", () => {
  const cases = [
    [[5, 7], 4],
    [[9, 12], 8],
    [[5, 13], 0],
    [[0, 1], 0],
    [[0, 0], 0],
    [[1, 1], 1]
  ];

  cases.forEach(([args, expected]) => {
    test(`returns ${expected} for ${[...args]}`, () => {
      expect(rangeBitwiseAnd(...args)).toEqual(expected);
    });
  });
});
